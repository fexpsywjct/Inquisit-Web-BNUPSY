from PIL import Image
from PIL import ImageDraw
from PIL import ImageFont
raw = (0, 1, 2, 3, 4, 5, 6, 7, 8)
for pic in raw:
    m = pic * 5
    gray_image = Image.new("RGB", size=(1000, 1000), color=(m,m,m))
    txt = "H"
    font = ImageFont.truetype("C:/Windows/Fonts/Arial.ttf", size=400)
    draw = ImageDraw.Draw(gray_image, mode="RGB")
    draw.text((300, 300), txt, fill=(255, 255, 255), font=font)
    name = "Pic"+str(pic)+".bmp"
    gray_image.save(name, "bmp")
    gray_image = Image.open(name)
    blank_image = Image.open(name)
    out = blank_image.crop(box=(55, 113, 855, 913))
    out.save(name)